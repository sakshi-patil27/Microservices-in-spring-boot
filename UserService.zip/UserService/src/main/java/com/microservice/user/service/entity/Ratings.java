package com.microservice.user.service.entity;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Ratings {
	private String ratringId;
	private String userid;
	private String hotelId;
	private int rating;
	private String feedback;
	
	private Hotel hotel;

}
