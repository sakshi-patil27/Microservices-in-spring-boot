package com.microservice.user.service.services.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.microservice.user.feign.HotelService;
import com.microservice.user.service.entity.Hotel;
import com.microservice.user.service.entity.Ratings;
import com.microservice.user.service.entity.User;
import com.microservice.user.service.exception.ResourceNotFoundException;
import com.microservice.user.service.repo.UserRepository;
import com.microservice.user.service.services.UserService;

@Service
public class UserServicesImpl implements UserService {

	@Autowired
	private UserRepository userRepo;
	@Autowired
	private RestTemplate resttemplate;
	
//	@Autowired
//	private HotelService hotelservice;
	
	@Override
	public User userSave(User user) {
		String id=UUID.randomUUID().toString();
        user.setUserId(id);
;	 return this.userRepo.save(user);
	}

	@Override
	public List<User> getUsers() {
		return this.userRepo.findAll();
	}

	@Override
	public User getUser(String userId) {
		User user= this.userRepo.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User with given id is not found on server" + userId));
		Ratings[] list1 =  resttemplate.getForObject("http://RATINGSERVICE/rating/getRatingsByUserId/users/"+user.getUserId(),Ratings[].class);
	
		List<Ratings> list=Arrays.stream(list1).toList();
		List<Ratings> ratinglist=list.stream().map(rating -> {
	   Hotel hotel1=resttemplate.getForObject("http://HOTELSERVICE/hotel/getHotel/"+rating.getHotelId(), Hotel.class);
//		 Hotel hotel1=  hotelservice.getHOtel(rating.getHotelId());
			rating.setHotel(hotel1);
			return rating;
		}).collect(Collectors.toList());
		
		user.setRatings(ratinglist);
		System.out.println(list);
		return user;
	}

}
